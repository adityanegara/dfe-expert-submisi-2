const links = [
  {
    id: 1,
    href: '#/near-you',
    caption: 'Home',
    tabindex: 0,
  },
  {
    id: 2,
    href: '#/favorite',
    caption: 'Favorite',
    tabindex: 0,
  },
  {
    id: 3,
    href: 'https://github.com/adityanegara',
    caption: 'About',
    tabindex: 0,
  },
];

export default links;
